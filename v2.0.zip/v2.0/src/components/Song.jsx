import { useState } from "react";
import { useEffect } from "react";

const Song = ()=>{
    //var songs= [] ;
    // Re-Rendering
    const [songs, setSongs] = useState([]);
    useEffect(()=>{
        getSongs();
    },[])
    // Song Come from the API
    // JSON {key:value}
    // JSON convert JSX (HTML)
    const getSongs = async ()=>{
        const URL = 'https://itunes.apple.com/search?term=daler mehndi&limit=25';
        // response contains header and body
        // data inside body
        const response = await fetch(URL); // wait for the data
        const data = await response.json();
        //console.log('Data Rec ', data);
        //songs = data.results;
        setSongs(data.results); // state change UI Render
        console.log('All Songs are ', songs);

    }
   // getSongs();
    return (<>
    {songs.length==0 && <p>Loading....</p>}
     {songs.map((song,index)=><div key={index}>
        {song.artistName}
        {song.trackName}
        <audio  controls src={song.previewUrl}>
            <source type="audio/mp4"/>
        </audio>
     </div>)}
    </>);
}
export default Song;

/*
<audio controls>
  
  <source src="horse.mp3" type="audio/mp4">
  Your browser does not support the audio tag.
</audio>

*/
// Writing Our First Component
// Component is Just a Function, 
// contains UI Code

import Header from "./components/Header";
import Song from './components/Song';
// Arrow Function
const App = ()=><><Header/><Song/></>
  

// function App(){
//   return (<h1>Hello react js</h1>)
// }
export default App;
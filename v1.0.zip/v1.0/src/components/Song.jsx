import { useEffect } from "react";

const Song = ()=>{

    useEffect(()=>{
        getSongs();
    },[])
    // Song Come from the API
    // JSON {key:value}
    // JSON convert JSX (HTML)
    const getSongs = async ()=>{
        const URL = 'https://itunes.apple.com/search?term=jack johnson&limit=25';
        // response contains header and body
        // data inside body
        const response = await fetch(URL); // wait for the data
        const data = await response.json();
        console.log('Data Rec ', data);
    }
   // getSongs();
    return (<h2>Song</h2>);
}
export default Song;
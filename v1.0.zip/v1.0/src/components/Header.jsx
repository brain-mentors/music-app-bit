const Header = ()=><h1>Music App</h1>
export default Header;